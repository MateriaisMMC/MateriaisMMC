library(geoR)
#Dataset
data(soja98)
soja <- data.frame(cbind(soja98[,1:2], soja98[,7]))
Soja <- as.geodata(soja)
summary(Soja)
?soja98

#Exploratory Analysis
points(Soja,xlab="X Coord",ylab="Y Coord")
#title(main="Data Observated")

plot(Soja,lowess=T)
names(Soja)

points(Soja,xlab="X Coord",ylab="Y Coord")
rect(99, 66, 113, 73, border = "red")
#title(main="Data Observated")

boxplot(Soja$data,horizontal =T)$out
# Located depended 
summary(lm(Soja$data~Soja$coords))

#residuals study
aux<-lm(Soja$data~Soja$coords[,2]); aux
par(mfrow=c(2,2))
plot(aux$residuals,main= "Residuals' Graph")
hist(aux$residuals,main= "Residuals' Histogram ",freq=F,ylim = c(0,0.05))
curve(dnorm(x, mean=mean(aux$residuals),sd=sd(aux$residuals)),add=T)
plot(aux,which = 2) 
abline(0,1)
plot(fitted(aux),rstandard(aux),main="Residuals vs values estimated")
abline(h=0)
abline(h=2.5,col="red")
abline(h=-2.5,col="red")

#testes de hipoteses
library(nortest)
ks.test(aux$residuals, "pnorm",mean(aux$residuals), sd(aux$residuals))
t.test(aux$residuals)
bartlett.test(Soja$data~Soja$coords[,2])
library(lmtest)
dwtest(Soja$data~Soja$coords[,2])

# Variogram
v <- variog(Soja, trend=~Soja$coords[,2],pairs.min=30, max.dist=85)
plot(v, main="Residuals' Variogram", cex.main=1.0)
text(pos=1,v$u, v$v,labels=as.character(v$n), cex=0.6)

#Inference
mvexp <- likfit(Soja,trend=~Soja$coords[,2], ini.cov.pars=c(20,30), cov.model="exp")
mvesf <- likfit(Soja,trend=~Soja$coords[,2], ini.cov.pars=c(20,30), cov.model="spherical")
mvma <- likfit(Soja,trend=~Soja$coords[,2], ini.cov.pars=c(20,30), cov.model="matern",
               kappa = 0.8,limits = pars.limits(phi=c(10, 80)))


library(data.table)
data.1 <- data.table("Model"=c("Exponential MV","Spherical MV","Matern MV"),
                     "beta0 "=c(67.8338,66.9062,68.1683),
                     "beta1 "=c(-0.2087,-0.1987,-0.2119),"tau^2 "=c(21.3914,38.9651,41.6605),
                     "sigma^2"=c(93.3430,72.6994,76.3558),"phi"=c(10.4672,25.1708,10.0000))
library(formattable)
formattable(data.1)

#Variogram

plot(v)
lines(mvexp,col="blue",lty=1)
lines(mvesf,col="red",lty=1)
lines(mvma,col="green",lty=1)
legend("bottomright",legend=c("Empirical Variogram","Exponential model (MV)",
                              "Spherical Model (MV)"," Matern Model (MV)"),
       pch=c(1,-1,-1,-1),lty=c(0,1,1,1),col=c("black","blue","red","green"),cex=0.8,bty="n")

#Validate study
mv_exp<-xvalid(Soja,model=mvexp)
mean(mv_exp$error)
mean((mv_exp$std.error)^2)
mv_esf<-xvalid(Soja,model=mvesf)
mean(mv_esf$error)
mean((mv_esf$std.error)^2)
mv_ma<-xvalid(Soja,model=mvma)
mean(mv_ma$error)

data.1 <- data.table("Model"=c("MVEXP","MVESF","MVMA"), 
                     "EQM "=c(0.05100222,0.04895033,0.05021369),
                     "EQMS"=c(0.99489,0.994386,0.9949521
))
formattable(data.1)
mean((mv_ma$std.error)^2)

#Prediction Grid
g<-list(xg=seq(min(Soja$coords[,1]),max(Soja$coords[,1]),length=60),
        yg=seq(min(Soja$coords[,2]),max(Soja$coords[,2]),length=50))
new_loc<- expand.grid(g)
plot(new_loc,pch=20)

# Kriging saturation

KC <- krige.control(type.krige = "ok", trend.d=~Soja$coords[,2],
                    trend.l=~new_loc[,2],obj=mvma)
krig <- krige.conv(Soja,locations=new_loc, krige=KC)
par(mfrow=c(2,1))
contour(krig,filled=TRUE,coords.data=Soja$coords)
contour(krig, val=sqrt(krig$krige.var),
        filled=TRUE, coords.data=Soja$coords)

library(dplyr)
library(geoR)
library(sf)
library(tripack)
library(spdep)
library(spData)
library(sp)
data(package = "spData")

#https://usepa.github.io/spmodel.spatialstat2023/

# Soja --------------------------------------------------------------------

#Base de dados (Geoestatistica)
data(soja98)
class(soja98)
?soja98
soja <- data.frame(cbind(soja98[,1:2], soja98[,7]))
Soja <- as.geodata(soja)

#Analise exploratória de dados
names(Soja)
summary(Soja)

#Outliers
boxplot(Soja$data,horizontal =T, col = "lightblue", xlab= "Níveis de Saturação",
        main="Análise de Outliers")$out #18.60 14.89

points(Soja,xlab="X Coord",ylab="Y Coord", main="Gráfico de Dispersão")

#ver os dois pontos pequenos
xy=locator(2)
xy
points(xy, col="red", cex=1.2, pch=3)

plot(Soja)


hist(Soja$data, col = "lightblue", main = "Histograma", xlab = "Saturação do Solo", ylab = "Frequência das Observações")

shapiro.test(Soja$data) #0.1449

#                             2ª Parte
plot(Soja)

mod1<-lm(Soja$data~Soja$coords, data=Soja)
summary(mod1)

mod2<-lm(Soja$data~Soja$coords[,2], data=Soja)
summary(mod2)

# Variograma Empirico
summary(Soja)
182.628037*0.6 #110


v.e <- variog(Soja, trend = ~ Soja$coords[,2], max.dist =110)
plot(v.e, xlab= "Distância", ylab="Variância", main="Variograma dos residuos (após excluir tendência)")

#paramentros visualizados
tau2=90
sigma2=120-90;sigma2
phi=50

# Variograma Teórico
#MMQ
v.t.e_MMQ <- variofit(v.e, cov.model = "exp", 
                      ini.cov.pars = c(sigma2,phi), nugget = tau2);v.t.e_MMQ
lines(v.t.e_MMQ, col="blue",lty=1)
v.t.e_MMQ$beta.ols

v.t.sph_MMQ <- variofit(v.e, cov.model = "sph", 
                      ini.cov.pars = c(sigma2,phi), nugget = tau2);v.t.sph_MMQ
lines(v.t.sph_MMQ, col="blue",lty=2)
v.t.sph_MMQ$beta.ols

#MV. 
v.t.e_MV <-likfit(Soja, trend = ~ Soja$coords[,2],  cov.model = "exp", 
                  ini.cov.pars = c(sigma2,phi), nugget = tau2);v.t.e_MV
lines(v.t.e_MV, col="red",lty=1)

v.t.sph_MV <-likfit(Soja, trend = ~ Soja$coords[,2],  cov.model = "sph", 
                  ini.cov.pars = c(sigma2,phi), nugget = tau2);v.t.sph_MV
lines(v.t.sph_MV, col="red",lty=2)

legend(list(x=40,y=40),pch=c(1,-1,-1,-1,-1), lty=c(0,1,2,1,2),
       col=c("black","blue","blue","red","red"),
       c("variograma experimental", "modelo exponêncial (MMQ)","modelo esférico (MMQ)",
         "modelo exponêncial (MV)", "modelo esférico (MV)"), cex=0.8, bty="n")

# Escolher melhor modelo por validação cruzada

xv.e.MMQ <- xvalid(Soja, model= v.t.e_MMQ)
xv.sph.MMQ <- xvalid(Soja, model= v.t.sph_MMQ)

xv.e.MV <- xvalid(Soja, model= v.t.e_MV)
xv.sph.MV <- xvalid(Soja, model= v.t.sph_MV)

# Erro Médio (deve estar próximo de 0)
mean(xv.e.MMQ$error) #0.03652635
mean(xv.e.MV$error)  #0.05100284

mean(xv.sph.MMQ$error) #0.03517432
mean(xv.sph.MV$error)  #0.04872269


# Erro Quadrático Médio Standardizado (deve estar próximo de 1)
mean((xv.e.MMQ$std.error)^2) #0.8867177
mean((xv.e.MV$std.error)^2)  #0.9948919

mean((xv.sph.MMQ$std.error)^2) #0.9097558
mean((xv.sph.MV$std.error)^2)  #0.9955137

# Fazer tabela, e decidir qual o melhor modelo (esferico MMQ)

# Fórmula

# Kriging universal

#Predição espacial – kriging universal (com tendencia que depende das localizaçoes)

library(gstat)
library(sp)
library(sf)
summary(Soja)

gr0x <- seq(1,500, by=5)
gr0y <- seq(1,500, by=5)
gr0 <- expand.grid(gr0x, gr0y)
dim(gr0) #pontos todos dentro da grelha
names(gr0)
points(Soja)
points(gr0, pch=".",cex=4 ,col=2)

p1 <- Polygon(cbind(c(0,200,200,0,0), c(0,0,200,200,0)))
polys <- Polygons(list(p1), "p1")
sp_poly <- SpatialPolygons(list(polys))


gr <- polygrid(gr0x, gr0y, bor=sp_poly)


KC <- krige.control(type.krige = "ok", trend.d=~Soja$coords[,2], 
                    trend.l=~gr[,2], obj=v.t.sph_MMQ) 

kr <- krige.conv(geodata=Soja, locations=gr0, krige=KC, borders=sp_poly)
kr$pred

krig.ests <- as.geodata(cbind(gr, kr$pred))

points(krig.ests, col=2, add=T)

################


valores_krigagem <- kr$pred

# Criar SpatialPixelsDataFrame
spdf <- SpatialPixelsDataFrame(points = gr, data = data.frame(valor = valores_krigagem))

spplot(spdf, "valor", main = "Estimativas de Krigagem", col.regions = topo.colors(100))

# grafico
spplot(spdf, "valor", main = "Estimativas de Krigagem", col.regions = topo.colors(100),
       scales = list(draw = TRUE, col = "black", fontface = "plain"))





# us_states final ---------------------------------------------------------


### Vamos juntar as bases de dados us_states (49 obs) e us_states_df (51 obs)
#   para isso as bases de dados têm de ter o mesmo nº de observações

data("us_states")
data("us_states_df")

# Listar os nomes dos estados de cada conjunto de dados
estados_us_states <- us_states$NAME
estados_us_states_df <- us_states_df$state

# Encontrar os estados que estão em us_states_df mas não em us_states
estados_extras <- setdiff(estados_us_states_df, estados_us_states);estados_extras #"Alaska" "Hawaii"


# Filtrar o conjunto de dados para excluir "Alaska" e "Hawaii"
us_states_df_filtrado <- filter(us_states_df, !(state %in% c("Alaska", "Hawaii")))

dim(us_states_df_filtrado) #49  5
dim(us_states) #49  7

us_states_df_filtrado$state
us_states$NAME

### Para juntar as duas bases de dados temos de fazer corresponder as observações 
#   de acordo com os estados o que não acontece como visto nos dois codigos anteriores


# Calcular os centroides
centroids <- st_centroid(us_states)

# Adicionar as coordenadas dos centroides como novas colunas
us_states_with_coords <- us_states %>% 
  mutate(longitude = st_coordinates(centroids)[,1],
         latitude = st_coordinates(centroids)[,2])

# Remover a coluna de geometria original
us_states_no_geom <- st_drop_geometry(us_states_with_coords)

# Combinar os conjuntos de dados e criar uma nova base de dados
dados <- left_join(us_states_no_geom, us_states_df_filtrado, by = c("NAME" = "state"))


# Analise exploratoria de dados

names(dados)
summary(dados)

# Histograma para População Total em 2015
hist(dados$total_pop_15, main = "Distribuição da População Total em 2015", 
     xlab = "População Total", col = "lightblue")



summary(dados)

#Distribuiçao das variaveis principais

quartz()
par(mfrow = c(2, 2))
# Histograma para median_income_10
hist(dados$median_income_10, main = "Distribuição da Mediana do Rendimento em 2010", 
     xlab = "Mediana do Rendimento", ylab="Frequência", col = "skyblue")

# Histograma para median_income_15
hist(dados$median_income_15, main = "Distribuição da Mediana do Rendimento em 2015", 
     xlab = "Mediana do Rendimento", ylab="Frequência", col = "#CDB7B5")



# Padronizar os dados do nível de pobreza em 2010 e 2015, estão em percentagem


dados$poverty_level_10<- (dados$poverty_level_10 / dados$total_pop_10)*100



dados$poverty_level_15<- (dados$poverty_level_15 / dados$total_pop_15)*100

View(dados)

#Acho q estes grafico nao interessam
# Histograma para poverty_level_10
hist(dados$poverty_level_10, main = "Distribuição do Nível de Pobreza em 2010",
     xlab = "Pessoas no limiar de pobreza", ylab="Frequência", col = "skyblue")

# Histograma para poverty_level_15
hist(dados$poverty_level_15, main = "Distribuição do Nível de Pobreza em 2015",
     xlab = "Pessoas no limiar de pobreza", ylab="Frequência", col = "#CDB7B5")




library(ggplot2)
library(reshape2)
library(scales)
# Transformar os dados para o formato longo para usar no ggplot2
dados_long <- reshape2::melt(dados, id.vars = "NAME", measure.vars = c("total_pop_10", "total_pop_15"))


# Gráfico de barras empilhadas 
ggplot(dados_long, aes(x = NAME, y = value, fill = variable)) +
  geom_bar(stat = "identity", position = "dodge") +
  scale_fill_manual(values = c("skyblue", "#CDB7B5"), labels = c("2010", "2015")) +
  labs(fill = "Ano", x = "Estado", y = "População Total") +
  theme(axis.text.x = element_text(angle = 90, hjust = 1)) +
  scale_y_continuous(labels = label_number()) +  # Formata os números do eixo y
  ggtitle("Comparação da População Total dos Estados em 2010 e 2015")


#Mapa por Regioes

# Definir cores personalizadas e rótulos em português para cada região
cores_regioes <- c("Nordeste" = "#B0E0E6", "Meio-Oeste" = "#7CCD7C", "Sul" = "#EEDD82", "Oeste" = "#CD9B9B")

# Tradução dos nomes das regiões 
nomes_regioes <- c("Nordeste", "Meio-Oeste", "Sul", "Oeste")

# Ajuste na coluna REGION para os nomes em português
us_states$REGION <- factor(us_states$REGION, levels = c("Norteast", "Midwest", "South", "West"), labels = nomes_regioes)

ggplot(data = us_states) +
  geom_sf(aes(fill = REGION)) +  # Preenche com base na região
  geom_sf_text(aes(label = NAME), size = 3, check_overlap = TRUE) +  # Adiciona os nomes dos estados
  scale_fill_manual(values = cores_regioes, 
                    name = "Região", 
                    labels = nomes_regioes) +  # Usa o vetor de cores e rótulos personalizados
  labs(title = "Estados dos EUA por Região") +
  theme_minimal() +
  theme(legend.position = "bottom") # Ajusta a posição da legenda

nlevels(dados$REGION)
# 4 niveis

levels(dados$REGION)
# "Norteast" "Midwest"  "South"    "West"  

table(dados$REGION)
# Norteast  Midwest    South     West 
#9       12 17       11 


quartz()
par(mfrow=c(2,2))


# Ajuste na coluna REGION para os nomes em português
dados$REGION <- factor(dados$REGION, levels = c("Norteast", "Midwest", "South", "West"), labels = nomes_regioes)

# Comparações dos dados de pobreza e rendimento mediano por região

# Dados de Pobreza em 2010
boxplot(dados$poverty_level_10 ~ dados$REGION, col=cores_regioes,
        ylab="% da População em situação de Pobreza em 2010", xlab = "Região", 
        main= "Distribuição do Nível de Pobreza em 2010 por Região")

# Dados de Pobreza em 2015
boxplot(dados$poverty_level_15 ~ dados$REGION, col=cores_regioes,
        ylab="% da População em situação de Pobreza em 2015", xlab = "Região", 
        main= "Distribuição do Nível de Pobreza em 2015 por Região")

# Dados do Rendimento Médio em 2010
boxplot(dados$median_income_10 ~ dados$REGION, col=cores_regioes,
        ylab="Rendimento Mediano em 2010 (USD)", xlab = "Região", 
        main= "Distribuição do Rendimento Mediano em 2010 por Região")

# Dados do Rendimento Médio em 2015
boxplot(dados$median_income_15 ~ dados$REGION, col=cores_regioes,
        ylab="Rendimento Mediano em 2015 (USD)", xlab = "Região", 
        main= "Distribuição do Rendimento Mediano em 2015 por Região")



## Análise Espacial
library(sp)
library(sf)

names(dados)

dados_sf <- st_as_sf(dados, coords = c("longitude", "latitude"))

names(dados_sf)

#  Distribuição espacial da variável Rendimento Mediano

ggplot(dados_sf, aes(color = median_income_15)) +
  geom_sf(size = 2) +
  scale_color_viridis_c() +
  labs(title = "Distribuição espacial da variável Rendimento Mediano 2015",
       color = "Rendimento Mediano 2015")

#  Distribuição espacial da variável Nivel de pobreza 2015
ggplot(dados_sf, aes(color = poverty_level_15)) +
  geom_sf(size = 2) +
  scale_color_viridis_c() +
  labs(title = "Distribuição espacial da variável Nível de Pobreza 2015",
       color = "Nível de Pobreza 2015")


#                          2ª Parte


# Teste de Moran, para averiguar se há correlação espacial
#      H0: não há correlação espacial - cor[yi,yj]=0
# objetivo é rejeitar para haver correlação, nos residuos já queremos que não haja

nb <- tri2nb(as.matrix(dados [, 7:8]))
W <- nb2listw(nb, style = "W")

###
# VERIFICAR SE HÁ CORRELAÇÃO ESPACIAL PARA A VARIÁVEL poverty_level_15
###
moran.test(dados$poverty_level_15, W, alternative = "two.sided")
#Moran I statistic =  0.486311938   
#p-value = 7.932e-10 < alfa, rejeitamos H0, há correlação espacial
#Expectation =-0.02083333  =-1/(49-1)

###
# VERIFICAR SE HÁ CORRELAÇÃO ESPACIAL PARA A VARIÁVEL median_income_15
###
moran.test(dados$median_income_15, W, alternative = "two.sided")
#p-value = 8.337e-09


###
# APLICAR DIFERENTES MODELOS PARA AVERIGUAR SE A VARIAVEL median_income_15 EXPLICA O MODELO
###

# Fazer tabela com os resultados do modelo lm, SAR e SMA com os dados seguintes:

#                                       Modelo lm

model_LM <- lm(dados$poverty_level_15 ~ dados$median_income_15, data = dados)
summary(model_LM)
AIC(model_LM)

# Verifcar se os residuos sao independentes:
# - NOTA: Não podemos usar um modelo lm, se falhar o pressuposto da independencia (slide 10)

library(spdep)
model_LM.moran <- lm.morantest(model_LM, W, alternative = "greater", 
                               resfun = weighted.residuals);model_LM.moran 
#  p-value = 0.00486 <alfa, rejeitamos H0, ha correlação espacial, 
# os residuos nao sao independentes falhou o pressuposto nao podemos usar o lm


#                                       Modelo SAR

library(spatialreg)
?lagsarlm
model_SAR <- lagsarlm(dados$poverty_level_15  ~ dados$median_income_15, data = dados, W, 
                      method = "eigen", quiet = TRUE)
summary(model_SAR)
# Rho: 0.48481, LR test value: 8.9215, p-value: 0.0028183-  parametro de correlação ( é significativo)
AIC(model_SAR)

#     residual standard error
sqrt(model_SAR$SSE/nrow(dados))

#      Verifcar se os residuos sao independentes
moran.test(model_SAR$residuals, W, alternative = "two.sided") 
#p-value = 0.374 nao ha correlação espacial nos residuos


#                                       Modelo SMA

library(spatialreg)
?errorsarlm
model_SMA <- errorsarlm(dados$poverty_level_15  ~ dados$median_income_15, data = dados, W, 
                        method = "eigen", quiet = TRUE)
summary(model_SMA)
#Lambda: 0.49768, LR test value: 4.8891, p-value: 0.027027- parametro de correlação (é significativo)

AIC(model_SMA)

#     residual standard error
sqrt(model_SMA$SSE/nrow(dados))

#        Verifcar se os residuos sao independentes
moran.test(model_SMA$residuals, W, alternative = "two.sided") 
#p-value = 0.8974 nao ha correlação espacial nos residuos (residuos independentes)
summary(model_SMA)



#                                    Modelo CAR
library(spatialreg)

model_CAR<- spautolm(dados$poverty_level_15 ~dados$median_income_15, data=dados, 
                     W, method = "eigen", family="CAR")
summary(model_CAR)
AIC(model_CAR)

#        Verifcar se os residuos sao independentes
moran.test(residuals(model_CAR), W, alternative = "two.sided") 
#p-value = 0.5778 > alfa, nao rejeitamos H0, nao ha correlaçao espacial dos residuos

#O modelo com menor AIC foi o modelo SAR



#               MODELOS ONDE INCLUIMOS TAMBEM A VARIAVEL REGION 

#                                      Modelo lm

model_LM2 <- lm(dados$poverty_level_15 ~ dados$median_income_15+REGION, data = dados)
summary(model_LM2)
AIC(model_LM2)

# Verifcar se os residuos sao independentes

model_LM.moran2 <- lm.morantest(model_LM2, W, alternative = "greater", 
                               resfun = weighted.residuals);model_LM.moran 
#  p-value = 0.4453 > alfa, NAO rejeitamos H0, NAO ha correlação espacial, 
# os residuos sao independentes nao falhou o pressuposto, podemos usar o lm


#                                       Modelo SAR


model_SAR2 <- lagsarlm(dados$poverty_level_15 ~ dados$median_income_15+REGION,  
                       data = dados, W, method = "eigen", quiet = TRUE)
summary(model_SAR2)
# Rho: 0.18211, LR test value: 0.92419, p-value: 0.33638-  parametro de correlação ( nao é significativo)
AIC(model_SAR2)



#      Verifcar se os residuos sao independentes
moran.test(model_SAR2$residuals, W, alternative = "two.sided") 
#p-value = 0.1861 nao ha correlação espacial nos residuos




#                                       Modelo SMA


model_SMA2 <- errorsarlm(dados$poverty_level_15  ~ dados$median_income_15+REGION, 
                         data = dados, W, method = "eigen", quiet = TRUE)
summary(model_SMA2)
#Lambda: -0.2463, LR test value: 0.80309, p-value: 0.37017 - parametro de correlação (nao é significativo)

AIC(model_SMA2)


#        Verifcar se os residuos sao independentes
moran.test(model_SMA2$residuals, W, alternative = "two.sided") 
#p-value = 0.8009 nao ha correlação espacial nos residuos (residuos independentes)

# Menor AIC model_LM2


#                              Modelo CAR
library(spatialreg)

model_CAR2<- spautolm(dados$poverty_level_15 ~dados$median_income_15+REGION, data=dados, 
                     W, method = "eigen", family="CAR")
summary(model_CAR2)
#Lambda: -0.14025 LR test value: 0.22355 p-value: 0.63634 
AIC(model_CAR2)

#        Verifcar se os residuos sao independentes
moran.test(residuals(model_CAR2), W, alternative = "two.sided") 
#p-value = 0.9093 > alfa, nao rejeitamos H0, nao ha correlaçao espacial dos residuos






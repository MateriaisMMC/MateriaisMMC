library(dplyr)
library(geoR)
library(sf)
library(tripack)
library(spdep)
library(spData)
data(package = "spData")
# Soja --------------------------------------------------------------------

#Base de dados (Geoestatistica)
data(soja98)
class(soja98)
?soja98
soja <- data.frame(cbind(soja98[,1:2], soja98[,7]))
Soja <- as.geodata(soja)

#Analise exploratória de dados
names(Soja)
summary(Soja)

#Outliers
boxplot(Soja$data,horizontal =T, col = "lightblue", xlab= "Níveis de Saturação",
        main="Análise de Outliers")$out #18.60 14.89

points(Soja,xlab="X Coord",ylab="Y Coord", main="Gráfico de Dispersão")

#ver os dois pontos pequenos
xy=locator(2)
xy
points(xy, col="red", cex=1.2, pch=3)

plot(Soja)


hist(Soja$data, col = "lightblue", main = "Histograma", xlab = "Saturação do Solo", ylab = "Frequência das Observações")

shapiro.test(Soja$data) #0.1449

#                             2ª Parte
plot(Soja)
#Nao sei se temos de criar um modelo primeiro e ver se retiramos uma das cordenadas
mod1<-lm(Soja$data~Soja$coords, data=Soja)
summary(mod1)

mod2<-lm(Soja$data~Soja$coords[,2], data=Soja)
summary(mod2)

# Variograma Empirico
summary(Soja)
182.628037*0.6 #110


#ou tren="1st"???????????????????????????
v.e <- variog(Soja, trend = ~ Soja$coords[,2], max.dist =110)
plot(v.e, xlab= "Distância", ylab="Variância", main="Variograma dos residuos (após excluir tendência)")

#paramentros visualizados
tau2=90
sigma2=120-90;sigma2
phi=50

# Variograma Teórico
#MMQ
v.t.e_MMQ <- variofit(v.e, cov.model = "exp", 
                      ini.cov.pars = c(sigma2,phi), nugget = tau2);v.t.e_MMQ
lines(v.t.e_MMQ, col="blue",lty=1)
v.t.e_MMQ$beta.ols

v.t.sph_MMQ <- variofit(v.e, cov.model = "sph", 
                      ini.cov.pars = c(sigma2,phi), nugget = tau2);v.t.sph_MMQ
lines(v.t.sph_MMQ, col="blue",lty=2)
v.t.sph_MMQ$beta.ols

#MV. mudar o trend??????????????????????
v.t.e_MV <-likfit(Soja, trend = "1st",  cov.model = "exp", 
                  ini.cov.pars = c(sigma2,phi), nugget = tau2);v.t.e_MV
lines(v.t.e_MV, col="red",lty=1)

v.t.sph_MV <-likfit(Soja, trend = "1st",  cov.model = "sph", 
                  ini.cov.pars = c(sigma2,phi), nugget = tau2);v.t.sph_MV
lines(v.t.sph_MV, col="red",lty=2)

legend(list(x=40,y=40),pch=c(1,-1,-1,-1,-1), lty=c(0,1,2,1,2),
       col=c("black","blue","blue","red","red"),
       c("variograma experimental", "modelo exponêncial (MMQ)","modelo esférico (MMQ)",
         "modelo exponêncial (MV)", "modelo esférico (MV)"), cex=0.8, bty="n")

# Escolher melhor modelo por validação cruzada

xv.e.MMQ <- xvalid(Soja, model= v.t.e_MMQ)
xv.sph.MMQ <- xvalid(Soja, model= v.t.sph_MMQ)

xv.e.MV <- xvalid(Soja, model= v.t.e_MV)
xv.sph.MV <- xvalid(Soja, model= v.t.sph_MV)

# Erro Médio (deve estar próximo de 0)
mean(xv.e.MMQ$error) #0.0393216
mean(xv.e.MV$error)  #0.0527569

# Erro Quadrático Médio (não interessa)
mean((xv.e.MMQ$error)^2) #81.01517
mean((xv.e.MV$error)^2)  #77.35948

# Erro Quadrático Médio Standardizado (deve estar próximo de 1)
mean((xv.e.MMQ$std.error)^2) #0.887763
mean((xv.e.MV$std.error)^2)  #0.9955618

# Fazer tabela, e decidir qual o melhor modelo
# Fórmula

# Kriging

# us_states e us_states_df -----------------------------------------------------------------



?us_states
View(us_states)
data(us_states)
class(us_states)
names(us_states)
us_states$GEOID
summary(us_states)

?us_states_df
data(us_states_df)
View(us_states_df)
names(us_states_df)
head(us_states_df)

#a partir da qui esta confuso 

us_states_centroids <- st_centroid(us_states)
names(us_states_centroids)
us_states_centroids$geometry

?st_coordinates
coordenadas <- st_coordinates(us_states_centroids$geometry)
head(coordenadas)
dim(coordenadas)

nb <- tri2nb(as.matrix(coordenadas));nb
W <- nb2listw(nb, style = "W")

#     To examine auto - correlation of residuals:
#H0: não há correlação espacial - cor[yi,yj]=0
# objetivo é rejeitar para haver correlação, nos residuos já queremos que não haja
moran.test(us_states$total_pop_10, W, alternative = "two.sided") 
#p-value = 0.295 > alfa, não rejeitamos H0, não há correlação espacial

#ver mail da prof...



# us_states final ---------------------------------------------------------


### Vamos juntar as bases de dados us_states (49 obs) e us_states_df (51 obs)
#   para isso as bases de dados têm de ter o mesmo nº de observações

data("us_states")
data("us_states_df")

# Listar os nomes dos estados de cada conjunto de dados
estados_us_states <- us_states$NAME
estados_us_states_df <- us_states_df$state

# Encontrar os estados que estão em us_states_df mas não em us_states
estados_extras <- setdiff(estados_us_states_df, estados_us_states);estados_extras #"Alaska" "Hawaii"


# Filtrar o conjunto de dados para excluir "Alaska" e "Hawaii"
us_states_df_filtrado <- filter(us_states_df, !(state %in% c("Alaska", "Hawaii")))

dim(us_states_df_filtrado) #49  5
dim(us_states) #49  7

us_states_df_filtrado$state
us_states$NAME

### Para juntar as duas bases de dados temos de fazer corresponder as observações 
#   de acordo com os estados o que não acontece como visto nos dois codigos anteriores


# Calcular os centroides
centroids <- st_centroid(us_states)

# Adicionar as coordenadas dos centroides como novas colunas
us_states_with_coords <- us_states %>% 
  mutate(longitude = st_coordinates(centroids)[,1],
         latitude = st_coordinates(centroids)[,2])

# Remover a coluna de geometria original
us_states_no_geom <- st_drop_geometry(us_states_with_coords)

# Combinar os conjuntos de dados e criar uma nova base de dados
dados <- left_join(us_states_no_geom, us_states_df_filtrado, by = c("NAME" = "state"))


# Analise exploratoria de dados

names(dados)
summary(dados)

# Histograma para População Total em 2015
hist(dados$total_pop_15, main = "Distribuição da População Total em 2015", 
     xlab = "População Total", col = "lightblue")






########### Análise Exploratória ##########

summary(dados)

#Distribuiçao das variaveis principais

quartz()
par(mfrow = c(2, 2))
# Histograma para median_income_10
hist(dados$median_income_10, main = "Distribuição da Renda Mediana em 2010", 
     xlab = "Renda Mediana", ylab="Frequência", col = "skyblue")

# Histograma para median_income_15
hist(dados$median_income_15, main = "Distribuição da Renda Mediana em 2015", 
     xlab = "Renda Mediana", ylab="Frequência", col = "#CDB7B5")


# Histograma para poverty_level_10
hist(dados$poverty_level_10, main = "Distribuição do Nível de Pobreza em 2010",
     xlab = "Pessoas no limiar de pobreza", ylab="Frequência", col = "skyblue")

# Histograma para poverty_level_15
hist(dados$poverty_level_15, main = "Distribuição do Nível de Pobreza em 2015",
     xlab = "Pessoas no limiar de pobreza", ylab="Frequência", col = "#CDB7B5")




library(ggplot2)
library(reshape2)
library(scales)
# Transformar os dados para o formato longo para uso com ggplot2
dados_long <- reshape2::melt(dados, id.vars = "NAME", measure.vars = c("total_pop_10", "total_pop_15"))


# Gráfico de barras empilhadas 
ggplot(dados_long, aes(x = NAME, y = value, fill = variable)) +
  geom_bar(stat = "identity", position = "dodge") +
  scale_fill_manual(values = c("skyblue", "#CDB7B5"), labels = c("2010", "2015")) +
  labs(fill = "Ano", x = "Estado", y = "População Total") +
  theme(axis.text.x = element_text(angle = 90, hjust = 1)) +
  scale_y_continuous(labels = label_number()) +  # Formata os números do eixo y
  ggtitle("Comparação da População Total dos Estados em 2010 e 2015")


#Mapa por Regioes

# Definindo cores personalizadas e rótulos em português para cada região
cores_regioes <- c("Nordeste" = "#B0E0E6", "Meio-Oeste" = "#7CCD7C", "Sul" = "#EEDD82", "Oeste" = "#CD9B9B")

# Tradução dos nomes das regiões para português
nomes_regioes <- c("Nordeste", "Meio-Oeste", "Sul", "Oeste")

# Ajuste na coluna REGION para os nomes em português
us_states$REGION <- factor(us_states$REGION, levels = c("Norteast", "Midwest", "South", "West"), labels = nomes_regioes)

ggplot(data = us_states) +
  geom_sf(aes(fill = REGION)) +  # Preenche com base na região
  geom_sf_text(aes(label = NAME), size = 3, check_overlap = TRUE) +  # Adiciona os nomes dos estados
  scale_fill_manual(values = cores_regioes, 
                    name = "Região", 
                    labels = nomes_regioes) +  # Usa o vetor de cores e rótulos personalizados
  labs(title = "Estados dos EUA por Região") +
  theme_minimal() +
  theme(legend.position = "bottom") # Ajusta a posição da legenda

nlevels(dados$REGION)
# 4 niveis

levels(dados$REGION)
# "Norteast" "Midwest"  "South"    "West"  

table(dados$REGION)
# Norteast  Midwest    South     West 
#9       12 17       11 



par(mfrow=c(2,2))

# Definindo as novas cores para cada região
cores_regioes <- c("Nordeste" = "#B0E0E6", "Meio-Oeste" = "#7CCD7C", "Sul" = "#EEDD82", "Oeste" = "#CD9B9B")

# Tradução dos nomes das regiões para português
nomes_regioes <- c("Nordeste", "Meio-Oeste", "Sul", "Oeste")

# Ajuste na coluna REGION para os nomes em português
dados$REGION <- factor(dados$REGION, levels = c("Norteast", "Midwest", "South", "West"), labels = nomes_regioes)

# Comparações dos dados de pobreza e rendimento mediano por região

# Dados de Pobreza em 2010
boxplot(dados$poverty_level_10 ~ dados$REGION, col=cores_regioes,
        ylab="Valores de Pobreza em 2010", xlab = "Região", 
        main= "Distribuição dos Dados de Pobreza em 2010 por Região")

# Dados de Pobreza em 2015
boxplot(dados$poverty_level_15 ~ dados$REGION, col=cores_regioes,
        ylab="Valores de Pobreza em 2015", xlab = "Região", 
        main= "Distribuição dos Dados de Pobreza em 2015 por Região")

# Dados do Rendimento Mediano em 2010
boxplot(dados$median_income_10 ~ dados$REGION, col=cores_regioes,
        ylab="Valores do Rendimento Mediano em 2010", xlab = "Região", 
        main= "Distribuição dos Dados do Rendimento Mediano em 2010 por Região")

# Dados do Rendimento Mediano em 2015
boxplot(dados$median_income_15 ~ dados$REGION, col=cores_regioes,
        ylab="Valores do Rendimento Mediano em 2015", xlab = "Região", 
        main= "Distribuição dos Dados do Rendimento Mediano em 2015 por Região")



## Análise Espacial
library(sp)
library(sf)

names(dados)

dados_sf <- st_as_sf(dados, coords = c("longitude", "latitude"))

names(dados_sf)

#  Distribuição espacial da variável Rendimento Médio

ggplot(dados_sf, aes(color = median_income_15)) +
  geom_sf(size = 2) +
  scale_color_viridis_c() +
  labs(title = "Distribuição espacial da variável Rendimento Médio 2015",
       color = "Rendimento Médio 2015")

#  Distribuição espacial da variável Nivel de pobreza 2015
ggplot(dados_sf, aes(color = poverty_level_15)) +
  geom_sf(size = 2) +
  scale_color_viridis_c() +
  labs(title = "Distribuição espacial da variável Nível de Pobreza 2015",
       color = "Nível de Pobreza 2015")


#                          2ª Parte

#se necessário, correr novamente da linha 161 até 197

# Teste de Moran, para averiguar se há correlação espacial
#      H0: não há correlação espacial - cor[yi,yj]=0
# objetivo é rejeitar para haver correlação, nos residuos já queremos que não haja

nb <- tri2nb(as.matrix(dados [, 7:8]))
W <- nb2listw(nb, style = "W")
moran.test(dados$poverty_level_15, W, alternative = "two.sided")
#Moran I statistic = 0.427717599
#p-value = 4.262e-08 < alfa, rejeitamos H0, há correlação espacial
#Expectation =-0.02083333  =-1/(49-1)

moran.test(dados$median_income_15, W, alternative = "two.sided")
#p-value = 8.337e-09


# Fazer tabela com os resultados do modelo lm, SAR e SMA com os dados seguintes:

#         Modelos de regressão com auto-correlação espacial - lm

model_LM <- lm(dados$poverty_level_15 ~ dados$median_income_15, data = dados)
summary(model_LM)
AIC(model_LM)

library(spdep)
# - Não podemos usar um modelo lm, se falhar o pressuposto da independencia (slide 10)
?lm.morantest
model_LM.moran <- lm.morantest(model_LM, W, alternative = "greater", 
                               resfun = weighted.residuals);model_LM.moran 
#  p-value = 0.1176 >alfa, não rejeitamos H0, não ha correlação espacial sao independentes
#Nao falhou o pressuposto podemos usar o lm


#                                       Modelo SAR

library(spatialreg)
?lagsarlm
model_SAR <- lagsarlm(dados$poverty_level_15  ~ dados$median_income_15, data = dados, W, 
                      method = "eigen", quiet = TRUE)
summary(model_SAR)
# Rho: 0.22041, LR test value: 0.85803, p-value: 0.35429 -  parametro de correlação (não é significativo)
AIC(model_SAR)

#     residual standard error
sqrt(model_SAR$SSE/nrow(dados))

#      auto - correlação dos residuals:
moran.test(model_SAR$residuals, W, alternative = "two.sided") 
#p-value = 0.8459 nao ha correlação espacial nos residuos


#                                       Modelo SMA

library(spatialreg)
?errorsarlm
model_SMA <- errorsarlm(dados$poverty_level_15  ~ dados$median_income_15, data = dados, W, 
                        method = "eigen", quiet = TRUE)
summary(model_SMA)
#Lambda: 0.20898, LR test value: 0.67381, p-value: 0.41173 - parametro de correlação (não é significativo)

AIC(model_SMA)

#     residual standard error
sqrt(model_SMA$SSE/nrow(dados))

#      auto - correlação dos residuals:
moran.test(model_SMA$residuals, W, alternative = "two.sided") 
#p-value = 0.7517 nao ha correlação espacial nos residuos (residuos independentes)
summary(model_SMA)


#O modelo com menor AIC foi o modelo SMA, porém a variavel median_income_15 
# nao era significativa em nenhum dos modelos. Criamos um modelo novo incluindo tb a populaçao


#                  Modelo lm - incluindo median_income_15 e total_pop_15

model_LM2 <- lm(dados$poverty_level_15 ~ dados$median_income_15+dados$total_pop_15, data = dados)
summary(model_LM2)
AIC(model_LM2)


library(spdep)

?lm.morantest
model_LM2.moran <- lm.morantest(model_LM2, W, alternative = "greater", 
                               resfun = weighted.residuals);model_LM2.moran 
#  p-value = 0.1899 >alfa, não rejeitamos H0, não ha correlação espacial

#Neste caso tanto a variavel income como a variavel pop são estatisticamente significativas


#Ver a Regiao 

model_LM3 <- lm(dados$poverty_level_15 ~ dados$median_income_15+dados$REGION, data = dados)
summary(model_LM3)
AIC(model_LM3)


library(spdep)

?lm.morantest
model_LM3.moran <- lm.morantest(model_LM3, W, alternative = "greater", 
                               resfun = weighted.residuals);model_LM3.moran 
#  p-value = 0.03951 >alfa, rejeitamos H0, ha correlação espacial

#Neste caso tanto a variavel income como a variavel pop são estatisticamente significativas

#Ver regiao e total

model_LM4 <- lm(dados$poverty_level_15 ~ dados$median_income_15+dados$REGION+dados$total_pop_15, data = dados)








#Modelo CAR
library(spatialreg)
?spautolm


model_CAR<- spautolm(dados$poverty_level_15 ~dados$median_income_15, data=dados, 
                     W, method = "eigen", family="CAR")
summary(model_CAR)

#model sar
model_sar<- spautolm(dados$poverty_level_15 ~dados$median_income_15, data=dados, 
                     W, method = "eigen", family="SAR")
summary(model_sar)

        
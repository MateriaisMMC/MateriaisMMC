#############
# 19 OUTUBRO
library(geoR)
?cov.spatial

par(mfrow=c(2,2))
u <- seq(0, 1.4, by=0.05) #distancias no quadrado unitário [0, 1km]x[0, 1km]
# raio de influência (range) igual a 0.5 km
sigma2 <- 2; phi <- 0.5
Cov_u <- cov.spatial(u, cov.model= "spherical", cov.pars=c(sigma2,phi))
plot(u, Cov_u, type="l", xlab="distancias (km)", ylab="covariância")
plot(u, sigma2-Cov_u, type="l", xlab="distancias (km)", ylab="variograma")

# raio de influência (range) igual a 1 km
sigma2 <- 2; phi <- 1
Cov_u <- cov.spatial(u, cov.model= "spherical", cov.pars=c(sigma2,phi))
plot(u, Cov_u, type="l", xlab="distancias (km)", ylab="covariância")
plot(u, sigma2-Cov_u, type="l", xlab="distancias (km)", ylab="variograma")


?grf
xx <- runif(50,min=0, max=1) #abcissas
yy <- runif(50,min=0, max=1) #ordenadas
pontos <- cbind(xx,yy)
sigma2 <- 2; phi <- 1
dados <- grf(n=100, grid=pontos, cov.model="spherical", cov.pars=c(sigma2,phi))
class(dados)
points.geodata(dados)



# DESAFIO: Como fazer estimação NP apenas num ponto x0?



# Estimar o variograma para os dados do Parana, dpois de modelar mu(x)
library(geoR)
aux <- lm(parana$data ~ parana$coords)
summary(aux)

summary(parana) #max 619km
Zx <- as.geodata(cbind(parana$coords, aux$residuals)) #novo dataset
points(Zx)
?variog
plot(variog(Zx), max.dist=370)



#############
# 1 NOVEMBRO
############
# 
# Dados do Parana da library geoR
# tendência linear + MMQ
library(geoR)
par(mfrow=c(1,1))
bin1 <- variog(parana, trend="1st", max.dist=400)
plot(bin1)

?variofit
aux<- variofit(bin1, cov.model="exponential", ini.cov.pars=c(600, 250), nugget=300)
aux
lines(aux) 

# tendência linear + MV
?likfit
aux1<- likfit(parana, trend="1st", cov.model="exponential", ini.cov.pars=c(600, 250), nugget=300)
aux1
lines(aux1, col="blue")

legend(list(x=100,y=300), lty=c(1,1), col=c("black","blue"), 
       c("exponencial MMQ","exponencial MV"), cex=0.8, bty="n")



############# VALIDAÇÃO CRUZADA ############
# Como eleger um modelo para a estrutura de dependencia espacial recorrendo a validação-cruzada?
?xvalid
variog.MMQ.exp <- aux # variograma teorico obtido por minimos quadrados  
variog.MV.exp <- aux1 # variograma teorico obtido por maxima verosimilhanca
MMQ.exp.xv<- xvalid(parana, model=variog.MMQ.exp)
MV.exp.xv<- xvalid(parana, model=variog.MV.exp)

#EM:  erro de predição médio -- deve ser aprox. 0
mean(MMQ.exp.xv$error) #-0.06740816 
mean(MV.exp.xv$error) #-0.01699888
par(mfrow=c(1,2))
hist(MMQ.exp.xv$error); hist(MV.exp.xv$error)

mean((MMQ.exp.xv$error)^2) #demasiado sensivel aos outliers
mean((MV.exp.xv$error)^2)  

#erro de predição dividido pela raiz quadrada da variância de kriging
par(mfrow=c(1,2))
hist(MMQ.exp.xv$std.error); hist(MV.exp.xv$std.error)

#EQMS: erro quadrático médio standardizado -- deve ser aprox. 1
mean((MMQ.exp.xv$std.error)^2) # 1.132327 
#MSSE: average their squares
mean((MV.exp.xv$std.error)^2) # 0.9801177

# CONCLUSÃO: Por validação cruzada, o variograma teórico eleito será o obtido por MV
#            (melhor capacidade de predição)  




#############
# 9 NOVEMBRO  
#############
# KRIGING ORDINÁRIO - conjunto de dados exemplo1.txt
library(geoR)
dados<-read.table("Dados/exemplo1.txt", header=T)
dadosGeo<-as.geodata(dados)

vg.empirico <- variog(dadosGeo, uvec=25, max.dist=220)
exp.vg<-variofit(vg.empirico, ini.cov.pars=c(2,30), cov.model="exp", weights="npairs")

#########
# PASSO I- estimar Y(x) sobre 4 pontos 
#          OBJETIVO: definir locais de predição e adicioná-los à figura com valores observados
novos.locs <- rbind(c(90,40),c(150,30),c(40,175),c(10,210))
points(dadosGeo)
points(novos.locs,col=2,pch=4,cex=2)
title(main="Pontos observados mais 4 não-observados")

# Realizar krigagem ordinária em novos locais usando o modelo ajustado
krig.dados <- krige.conv(dadosGeo, loc=novos.locs,
#                        krige=krige.control(type.krige="ok", nugget=exp.vg$nugget, cov.pars=exp.vg$cov.pars))
                         krige=krige.control(type.krige="ok", obj=exp.vg))

# Para descobrir que tipo de informação produzimos, escreva
names(krig.dados)
# se eu quiser ver os valores previstos, escrevo:
krig.dados$pred
# para a variância de kriging, escreve-se
krig.dados$krige.var

# Podemos acrescentar os valores previstos nas suas localizações
# Para isso preciso colocar os dados no formato geodata:
points(dadosGeo)
#plot kriging estimators
krig.ests <- as.geodata(cbind(novos.locs, krig.dados$predict))
points(krig.ests, col=2, add=T)
title(main="Observações e 4 estimativas de kriging")

# Para se prever nos locais originalmente observados, basta definir
novos.locs <- dadosGeo$coords
# e repetir o procedimento anterior (linha 128 acima)
#
# EXERCÍCIO: Como interpretar os valores em krig.dados$pred e krig.dados$krige.var 
krig.dados <- krige.conv(dadosGeo, loc=novos.locs,
                         krige=krige.control(type.krige="ok", obj=exp.vg))
krig.dados$pred
krig.dados$krige.var



##########
# PASSO II- prever sobre uma grelha
#           OBJETIVO: Construir um mapa com os valores preditos na grelha
#
# Para criar uma grelha de 40 por 40 sobreposta ao domínio original, escreva:
g <-list(xg=seq(min(dadosGeo$coords[,1]), max(dadosGeo$coords[,1]), length=40),
         yg=seq(min(dadosGeo$coords[,2]), max(dadosGeo$coords[,2]), length=40))

# e defina as novas localizações como
novos.locs <- expand.grid(g)
# para desenhar a grelha, basta digitar:
plot(novos.locs,pch=20,main="40 by 40 prediction grid",xlab="X coordinate",ylab="Y coordinate")

#the rest follows as before:
krig.dados <- krige.conv(dadosGeo,loc=novos.locs,krige=krige.control(type.krige="ok", obj=exp.vg))


#to produce an image, contour or perspective plot of the predicted values, type:
contour(krig.dados, filled=TRUE, coords.data=dadosGeo$coords, main="Estimativas de Kriging")

#to produce an image, contour or perspective plot of the kriging variances, type:
contour(krig.dados, val=sqrt(krig.dados$krige.var),
        filled=TRUE, coords.data=dadosGeo$coords, main="Desvio Padrao de Kriging")




#############
# 30 NOVEMBRO  
#############

#############################################################################
# Algumas funções do R importantes para a análise de Dados Agregados por Área
library(spatstat)
?pairdist #Pairwise distances

library(spdep)
?moran.test #Moran's I test for spatial autocorrelation
?lm.morantest #Moran's I test for residual spatial autocorrelation

library(spatialreg)
?lagsarlm #Maximum likelihood estimation of SAR model
?errorsarlm #Maximum likelihood estimation of SMA model
?spautolm #Maximum likelihood estimation of all 3 models SAR, CAR and SMA



######################################################
# Como extrair coordenadas de um objeto da class "sf"?
library(spmodel)
class(sulfate)
sulfate
library(sf)
?st_coordinates
coordenadas <- st_coordinates(sulfate)
head(coordenadas)

##########################################################################
# Como guardar um par de coordenadas com o formato exigido pelo "spmodel"? 
class(sulfate$geometry)
install.packages("spmodel")
install.packages("sf")
library(spmodel)
library(sf)

coordinates <- cbind(x = c(1), y = c(4))
# Create an "sfc_POINT" object
point_sfc <- st_sfc(st_point(coordinates))
print(point_sfc)

# Repetir para 3 pares de coordenadas
data <- data.frame(x = c(1, 2, 3), y = c(4, 5, 6))
# Create an "sf" object with POINT geometries
points_sf <- st_as_sf(data, coords = c("x", "y"), crs = 4326)
print(points_sf)



#############
# EXERCICIOS:  
#############
# a) Use a função "splm" para ajustar um modelo de regressão espacial 
#    SEM covariáveis aos dados de "exemplo1.txt"
# b) Use a função "splm" para ajustar um modelo de regressão espacial 
#    COM covariáveis aos dados de "ca20"
# c) Investigue funções disponíveis para avaliar o ajuste do modelo.
# d) Como fazer Kriging Ordinário com a biblioteca "spmodel"?
# e) Como fazer Kriging Universal (c tendência externa) com a biblioteca "spmodel"?

####
# a) Use a função "splm" para ajustar um modelo de regressão espacial 
#    SEM covariáveis aos dados de "exemplo1.txt"
dados<-read.table("/Users/raquelmenezes/Desktop/exemplo1.txt", header=T)
library(spmodel)
library(sf)
# Criar um objecto "sf" 
dados_sf <- st_as_sf(dados, coords = c("x", "y"))
print(dados_sf)
class(dados_sf)
spmod <- splm(data ~ 1, data = dados_sf, spcov_type = "exponential")
summary(spmod) #beta0=69.9204, sigma2=3.79085, phi=28.983, tau2=0.00128

# Vamos comparar com o geoR
library(geoR)
dadosGeo<-as.geodata(dados)
geomodel <- likfit(dadosGeo, ini.cov.pars=c(2,30), cov.model="exp")
geomodel #beta0=69.9021, sigma2=3.468, phi=25.87, tau2=0.0


####
# b) Use a função "splm" para ajustar um modelo de regressão espacial 
#    COM covariáveis aos dados de "ca20"
library(sf)
ca20_sf <- st_as_sf(as.data.frame(ca20), coords = c("east", "north"))
print(ca20_sf)
class(ca20_sf)
head(st_coordinates(ca20_sf))
summary(lm(data ~ altitude+area+st_coordinates(ca20_sf), data = ca20_sf))
spmod1 <- splm(data ~ st_coordinates(ca20_sf), data = ca20_sf, spcov_type = "exponential")
summary(spmod1); AIC(spmod1) #1276.799
spmod2 <- splm(data ~ st_coordinates(ca20_sf)[,2], data = ca20_sf, spcov_type = "exponential")
summary(spmod2); AIC(spmod2) #1269.303
spmod3 <- splm(data ~ altitude, data = ca20_sf, spcov_type = "exponential")
summary(spmod3) #não interessa
spmod4 <- splm(data ~ area, data = ca20_sf, spcov_type = "exponential")
summary(spmod4); AIC(spmod4) #1250.771 melhor AIC
#beta0=40.073 (se area1), beta1=7.402, beta2=13.767, sigma2=111.12, phi=111.86, tau2=12.35

glances(spmod1,spmod2,spmod3,spmod4) #compara todos os modelos

# Vamos comparar com o geoR
library(geoR)
geomodel <- likfit(ca20, trend=~area, ini.cov.pars=c(100,200), cov.model="exp")
geomodel 
#beta0=38.416 (se area1), beta1=8.543, beta2=15.581, sigma2=103.377, phi=71.775, tau2=0


####
# c) Funções úteis para avaliar o ajuste do modelo
tidy(spmod4)
glance(spmod1)
glance(spmod4)
augment(spmod4)


####
# d) Como fazer Kriging Ordinário com a biblioteca "spmodel"?
dados<-read.table("exemplo1.txt", header=T)
dados_sf <- st_as_sf(dados, coords = c("x", "y"))
spmod <- splm(data ~ 1, data = dados_sf, spcov_type = "exponential") #modelo sem preditores

# i. Predição em 4 pontos
aux <- data.frame(x=c(90,150,40,10), y=c(40,30,175,210))
novos.locs <- st_as_sf(aux, coords = c("x", "y"))
class(novos.locs)
predict(spmod, newdata=novos.locs) 
?predict.splm
predict(spmod, newdata=novos.locs, interval = "confidence")

# ii. Predição numa grelha
minx<-min(dadosGeo$coords[,1]); maxx<-max(dadosGeo$coords[,1])
miny<-min(dadosGeo$coords[,2]); maxy<-max(dadosGeo$coords[,2])
g <-list(x=seq(minx,maxx, length=40), y=seq(miny,maxy, length=40)) #40x40=1600
# e defina as novas localizações como
aux <- expand.grid(g)
novos.locs <- st_as_sf(aux, coords = c("x", "y"))
class(novos.locs)
predict(spmod, newdata=novos.locs) 

# A função augment() também pode ser usada para enriquecer os dados de previsão com as próprias previsões:
aug_preds <- augment(spmod, newdata = novos.locs) 
print(aug_preds)
ggplot(aug_preds, aes(color = .fitted)) + 
  geom_sf(size = 3.5) + scale_color_viridis_c(limits = c(66, 74))  #kriging ordinario




############
# 7 DEZEMBRO- DADOS REFERENTES A ÁREAS
############
library(spData)
data(package = "spData")

library(sf)
# 1. Começar por criar objeto da classe "sf" (à custa por exemplo do dataframe "dados")
dados_sf <- st_as_sf(dados, coords = c("x", "y"))
names(dados_sf)
dados_sf

# 2. Distribuição espacial da variável de interesse 
ggplot(dados_sf, aes(color = xxxx)) +
  geom_sf(size = 2) +
  scale_color_viridis_c(limits = c(LI, LS)) +
  labs(title = "Distribuição da variável xxxx")

# 3. Teste de Moran para a auto-correlação espacial entre poligonos 
?st_centroid
dados_centroids <- st_centroid(dados_sf) # cada área é identificada pelo respetivo poligono 
names(dados_centroids) # cada area passa a ser identificada pelo centroide 
dados_centroids

?st_coordinates
coordenadas <- st_coordinates(dados_centroids)
head(coordenadas)
dim(coordenadas)

nb <- tri2nb(as.matrix(coordenadas));nb
W <- nb2listw(nb, style = "W")
#  Para examinar a auto-correlação dos resíduos:
moran.test(dados$xxx, W, alternative = "two.sided") 



library(spmodel)
?spautor
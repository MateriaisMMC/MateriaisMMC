#############
# 19 OUTUBRO
library(geoR)
?cov.spatial

par(mfrow=c(2,2))
u <- seq(0, 1.4, by=0.05) #distancias no quadrado unitário [0, 1km]x[0, 1km]
# raio de influência (range) igual a 0.5 km
sigma2 <- 2; phi <- 0.5
Cov_u <- cov.spatial(u, cov.model= "spherical", cov.pars=c(sigma2,phi))
plot(u, Cov_u, type="l", xlab="distancias (km)", ylab="covariância")
plot(u, sigma2-Cov_u, type="l", xlab="distancias (km)", ylab="variograma")

# raio de influência (range) igual a 1 km
sigma2 <- 2; phi <- 1
Cov_u <- cov.spatial(u, cov.model= "spherical", cov.pars=c(sigma2,phi))
plot(u, Cov_u, type="l", xlab="distancias (km)", ylab="covariância")
plot(u, sigma2-Cov_u, type="l", xlab="distancias (km)", ylab="variograma")


?grf
xx <- runif(50,min=0, max=1) #abcissas
yy <- runif(50,min=0, max=1) #ordenadas
pontos <- cbind(xx,yy)
sigma2 <- 2; phi <- 1
dados <- grf(n=100, grid=pontos, cov.model="spherical", cov.pars=c(sigma2,phi))
class(dados)
points.geodata(dados)



# Como fazer estimação NP apenas num ponto x0?


############## 21/09
# EXERCICIO 1
# Gera 100 pontos no quadrado unitário debaixo dos 3 seguintes cenários:
# a) aleatoriedade espacial completa
# c) padrão correspondente a eventos fortemente agregados
# b) padrão regular  


par(mfrow=c(2,2))

# a) aleatorio
x1 <- runif(100,0,1)
y1 <- runif(100,0,1)
plot(x1,y1,cex=0.6)
library(spatstat)
#pp <- runifpoint(100)
#plot(pp)

# b) regular
x2 <- seq(0.05,0.95,by=0.1)#criar uma sequência de nº que começa em 0.05, termina em 0.95, e aumenta de 0.1 em 0.1. 
y2 <- seq(0.05,0.95,by=0.1)
xy2 <- expand.grid(x2,y2);xy2 #criar todas as combinacoes possiveis de valores x2 e y2
dim(xy2)
plot(xy2, xlab="x", ylab="y",cex=0.6)
#Poderia ser por ex localizacao de arvores q tem de estar equidistantes por causa 
#do crescimento da raiz, competicao de luz...


# c) agregado
a1 <- runif(25,0.4,0.6)
b1 <- runif(25,0.1,0.3)
a2 <- runif(50,0.1,0.3)
b2 <- runif(50,0.2,0.6)
a3 <- runif(25,0.6,0.9)
b3 <- runif(25,0.6,0.9)
x3 <- c(a1,a2,a3)
y3 <- c(b1,b2,b3)
plot(x3,y3,cex=0.6)

#Por exemplo se fosse uma doença conseguiamos ver onde ha maior probabilidade 
#de ficar doente

#########################################


# EXERCICIO 2
# b) Faça uma estimação não-paramétrica para a densidade de pontos dos 3 cenários simulados no Exercicio 1
library(spatstat)
?Smooth #para fazer analises exploratoria em estatistica espacial


# EXERCICIO 2
# b) Faça uma estimação não-paramétrica para a densidade de pontos dos 3 cenários simulados no Exercicio 1
library(spatstat)
?density.ppp
par(mfrow=c(2,2))

#aleatorio
dados.ppp <- ppp(x=x1, y=y1)
plot(density.ppp(dados.ppp), main = "aletorio")
points(dados.ppp, add=T)
?points.geodata

#regular 
dim(xy2)

dados.ppp <- ppp(x=xy2[,1], y=xy2[,2]) # xy2[,1] - coluna 1; xy2[,2] - coluna2
plot(density.ppp(dados.ppp, sigma=0.03), main="regular")
points(dados.ppp, cex=0.6)

#agregado
dados.ppp <- ppp(x=x3, y=y3)
plot(density.ppp(dados.ppp), main = "agregado")
points(dados.ppp, add=T, cex=0.8)


#############
# EXERCICIO 3
# a) Analise dos dados s100 da package geoR
library(geoR)
points(s100)
plot(s100)
summary(s100)
?Smooth.ppp

# b) Faça uma estimação não-paramétrica da variável de interesse, experimentando diferentes larguras de banda
library(spatstat)
?Smooth.ppp
dados.ppp <- ppp(x=s100$coords[,1], y=s100$coords[,2], marks=s100$data)
bw.smoothppp(dados.ppp)
plot(Smooth(dados.ppp)) #valor de pontos e nao probabilidade
points(s100, add=T)

par(mfrow=c(2,3))
plot(Smooth(dados.ppp, sigma=0.077), main="sigma=0.077")
points(s100, add=T)
plot(Smooth(dados.ppp, sigma=0.03), main="sigma=0.03")
points(s100, add=T)
plot(Smooth(dados.ppp, sigma=0.15), main="sigma=0.15")
points(s100, add=T)


# c) 

#############
# EXERCICIO 3
# Analise dos dados de precipitação do Parana
library(geoR)
?parana
class(parana)
summary(parana)
points(parana)
plot(parana)
names(parana)
?plot.geodata

library(spatstat)
?Smooth.ppp
dados.ppp <- ppp(x=parana$coords[,1], y=parana$coords[,2], marks=parana$data, 
                 #             window=as.owin(poly=parana$borders))
                 owin(xrange=range(parana$coords[,1]), yrange=range(parana$coords[,2])))
plot(Smooth(dados.ppp))
points(parana, add=T)

#19/10

points.geodata(parana)
xy=locator(1)
xy
points(xy, col="red", cex=1.2, pch=3)

library(geoR)
?cov.spatial

#Estimar variograma para o Parana, depois de modelar mu(x)

aux<-lm(parana$data ~parana$coords)
summary(aux)

zx<-as.geodata(cbind(parana$coords, aux$residuals))#novo dataset
points(zx)
?variog

summary(parana)#max 619km
0.6*619 #formula da distancia max??
plot(variog(zx), max.dist = 370)

#################### 26/10 ######################

################ Pergunta 6 ################
library(geoR)
data("s100")
summary(s100)
plot(s100)
points(s100)
y<-s100$data
mean(y) #tb esta no summary
var(y) # var. total: sigma^2+tau^2 !!!!IMPORTANTE!!!


?variog
# a) !!! tendência constante !!!
cloud1 <- variog(s100, option="cloud", max.dist=1)
bin1 <- variog(s100, max.dist=1) #option ="bin" é o default

#Estimadores classicos do tipo claud e do tipo ??
par(mfrow=c(1,2)) 
plot(cloud1, main="estimador classico") # nuvem com o nº de pares
plot(bin1, main="estimador classico") # vai fazendo a media dos pontos todos que estão na nuvem entre 0 e 0.2, 0.2 e 0.4...

# b) tendência linear e MMQ

#tendencia linear
par(mfrow=c(1,1))
summary(s100)

bin2 <- variog(s100, trend="1st", max.dist=1) #max.dist (o grafico para em 1) normalmente fazemos 0.6*dist max das coordenadas
#trend - remover a tendencia linear antes de estimar o variograma, ou seja tiramos a media - miu = (beta0+beta1long+beta2lat)
#estamos a modelar os residuos ??

names(bin2)
bin2$u  #distancias - U do grafico do caderno
bin2$v # estimativas do variograma (y do grafico caderno - gama^) aprox. 0.51 vamos por 0.6 no plot
bin2$n  # nº de pares
plot(bin2, ylim=c(0,0.6))

#MMQ
?variofit
aux<- variofit(bin1, cov.model="exponential", ini.cov.pars=c(0.3, 0.5), nugget=0.15)
aux
lines(aux)

aux1<- variofit(bin1, cov.model="spherical", ini.cov.pars=c(0.3, 0.5), nugget=0.15)
aux1
lines(aux1, col="red")

#Descobrir os betas 

lm(s100$data ~s100$coord)
summary(lm(s100$data ~s100$coord)) #os parametros sao significativos


# c) tendência linear e MV
#Neste caso com a funcao likfit já obtemos os betas
?likfit
aux2<- likfit(s100, trend="1st", cov.model="exponential", ini.cov.pars=c(0.3, 0.5), nugget=0.15)
aux2
lines(aux2, col="blue")
names(aux2)
aux2$cov.pars
aux2$beta # é o mesmo que fazer o lm

aux3<- likfit(s100, trend="1st", cov.model="spherical", ini.cov.pars=c(0.3, 0.5), nugget=0.15)
aux3
lines(aux3, col="green")
legend(list(x=0.4,y=0.25), lty=c(1,1,1,1), col=c("black","red","blue","green"),
       c("exponencial MMQ","esferico MMQ","exponencial MV","esferico MV"), cex=0.8, bty="n")





################ Pergunta 7 ################
library(geoR)
data("parana")
summary(parana)
plot(parana)

# a) tendencia linear e MMQ
# Estimação do variograma empírico com tendência linear
?variog

#Distancia maxima = 0.6* distancia max
619.4925*0.6 #= 371.6955

variograma_empirico <- variog(parana, trend="1st", max.dist=371.6955)
plot(variograma_empirico, main="Variograma Empírico", ylab="Variograma", xlab="Distância")
names(variograma_empirico)
variograma_empirico$v


# modelo exponencial por MMQ
?variofit
mod_exp<- variofit(variograma_empirico, cov.model="exponential", ini.cov.pars=c(700,250), nugget=600)
mod_exp
lines(mod_exp)

#modelo esferico 
mod_esf<- variofit(variograma_empirico, cov.model="spherical", ini.cov.pars=c(700,250), nugget=600)
mod_esf
lines(mod_esf, col="#4F94CD")
mod_esf$beta.ols #outra forma de saber os betas

#modelo matern
#mod_mat<-variofit(variograma_empirico, cov.model="matern", ini.cov.pars=c(700,200), nugget=500)
#lines(mod_mat, col="pink") #sobrepoe-se ao exponencial


#Descobrir os betas
modelo1<-lm(parana$data ~ parana$coord)
summary(modelo1) #os parametros sao significativos
#modelo$beta.ols  

# b) tendencia linear e MV

?likfit
mod_MV<- likfit(parana, trend="1st", cov.model="exponential", ini.cov.pars=c(700,250), nugget=600)
mod_MV
lines(mod_MV, col="#EE8262")

mod_MVesf<- likfit(parana, trend="1st", cov.model="spherical", ini.cov.pars=c(700,250), nugget=600)
mod_MVesf
lines(mod_MVesf, col="#66CDAA")

legend(list(x=200,y=400), lty=c(1,1,1), col=c("black","#4F94CD","#EE8262", "#66CDAA"),
       c("exponencial MMQ","esferico MMQ","exponencial MV","esferico MV"), cex=0.8, bty="n")


##02/11

?variofit 


library(geoR)
?ca20
data("ca20")
points(ca20)
plot(ca20)
#nao parecem ser estacionarios na media, ve-se no 2 grafico pq os pontos nao estao dispersos
names(ca20)
#area é uma var. categorica
   
modelo=lm(ca20$data ~ ca20$coords)
summary(modelo)


#Validaçao cruzada para escolher melhor modelo
#usando os dados do exercicio 7
?xvalid
variog.MMQ.exp <- mod_exp #variograma teorico obtido por minimos quadrados
variog.MV.exp <- mod_MV #variograma teorico obtido por maxima verosimilhanca

variog.MMQ.esf <- mod_esf
variog.MV.esf <- mod_MVesf

MMQ.exp.xv=xvalid(parana, model =variog.MMQ.exp)
MMQ.exp.xv
#> 314.4443-306.09 (diferença entre o valor previsto o dado observado dá-nos o error)
#[1] 8.3543 o valor dado pelo error 
MV.exp.xv= xvalid(parana, model = variog.MV.exp)

MMQ.esf.xv=xvalid(parana, model =variog.MMQ.esf)
MV.esf.xv=xvalid(parana, model =variog.MV.esf)

names(MMQ.exp.xv)

#EM
mean(MMQ.exp.xv$error)
mean(MV.exp.xv$error)

mean(MMQ.esf.xv$error)
mean(MV.esf.xv$error)
#EQM
mean((MMQ.exp.xv$error)^2)
mean((MV.exp.xv$error)^2)

mean((MMQ.esf.xv$error)^2)
mean((MV.esf.xv$error)^2)
#EQMs
mean((MMQ.exp.xv$std.error)^2)
mean((MV.exp.xv$std.error)^2)

mean((MMQ.esf.xv$std.error)^2)
mean((MV.esf.xv$std.error)^2)

par(mfrow=c(2,2))
hist(MMQ.exp.xv$error)
hist(MV.exp.xv$error)

hist(MMQ.esf.xv$error)
hist(MV.esf.xv$error)

#####################   09/11   ##################### 

#Ficha 2a - Kriging ordinário

setwd("/Users/carmenafonsoalves/Documents/2 ano/Espacial/Exercicios")
dados<- read.table("exemplo1.txt", header=TRUE)

# KRIGING ORDINÁRIO - conjunto de dados exemplo1.txt
library(geoR)
dadosGeo<-as.geodata(dados) #tornar os dados no formato geodata

plot(dadosGeo)
#Estes dados parecem nao ter tendencia por isso nao pomos o argumento tren="..." no vg.empirico
#Variograma empirico é sempre interessante fazer para ver os pontos de partida do grafico
vg.empirico <- variog(dadosGeo, uvec=25, max.dist=220)

# Quantos pares de pontos foram usados para estimar cada ponto do variograma empirico?
vg.empirico$n

vg.empirico$uvec

plot(vg.empirico, pch=20)

# Para representar graficamente o número de pares em cada "bin" no gráfico de variograma:
#por o nº de pares que foram utilizados para cada ponto do grafico
text(pos=1, vg.empirico$u, vg.empirico$v,labels=as.character(vg.empirico$n), cex=0.6)

#Estimar pelo metodo dos minimos quadrados 
exp.vg<-variofit(vg.empirico, ini.cov.pars=c(2,30), cov.model="exp", weights="npairs")

#########
# PASSO I- estimar Y(x) sobre 4 pontos (4 localizaçoes)
#          OBJETIVO: definir locais de predição e adicioná-los à figura com valores observados
novos.locs <- rbind(c(90,40),c(150,30),c(40,175),c(10,210));novos.locs  #criar 4 pontos dando uma (lat,long) para cada um
points(dadosGeo)
points(novos.locs,col=2,pch=4,cex=2)
title(main="Pontos observados mais 4 não-observados")

# Realizar krigagem ordinária em novos locais usando o modelo ajustado - Vamos prever para os 4 locais
krig.dados <- krige.conv(dadosGeo, loc=novos.locs,
# krige=krige.control(type.krige="ok", nugget=exp.vg$nugget, cov.pars=exp.vg$cov.pars)) - por os paramentros separadamente
                         krige=krige.control(type.krige="ok", obj=exp.vg))

# Para descobrir que tipo de informação produzimos, escreva
names(krig.dados)


krig.dados$beta.est # da nos o beta 0 =media (q era desconhecida)


# se eu quiser ver os valores previstos:
krig.dados$pred #predicoes para os 4 pontos novos (y^)

# para a variância de kriging, escreve-se
krig.dados$krige.var# medida de incerteza para as 4 estimativas

# desvios padroes
sqrt(krig.dados$krige.var)


# Podemos acrescentar os valores previstos nas suas localizações
# Para isso preciso colocar os dados no formato geodata:
points(dadosGeo)
#plot kriging estimators
krig.ests <- as.geodata(cbind(novos.locs, krig.dados$predict)) # matriz (4x2)(4x1)=(4x3)
points(krig.ests, col=2, add=T) #add=T é para por as bolas por cima das que já la estao
title(main="Observações e 4 estimativas de kriging")
#Pontos a vermelho sao as estimativas para os novos pontos 
#(bolas maiores sao valores mais altos e nao por ter mais localizaçoes naquela zona)
#ponto maior tem menos incerteza pq esta perto de mais pontos

#> krig.dados$pred #predicoes para os 4 pontos novos (y^)
#[1] 70.35218 70.99624 71.73499 69.60838 ----> 71.73 tem a menor variancia (menor incerteza)
#> # para a variância de kriging, escreve-se
#  > krig.dados$krige.var# medida de incerteza para as 4 estimativas
#[1] 1.628259 2.077840 1.060695 1.951139



# Prever agora para 150 pontos (para as proprias cordenadas observadas)
# Para se prever nos locais originalmente observados, basta definir
novos.locs <- dadosGeo$coords 

krig.dados <- krige.conv(dadosGeo, loc=novos.locs,
#krige=krige.control(type.krige="ok", nugget=exp.vg$nugget, cov.pars=exp.vg$cov.pars))
                         krige=krige.control(type.krige="ok", obj=exp.vg))


# valores previstos
krig.dados$pred
# variância de kriging
krig.dados$krige.var

head(krig.dados$pred)
head(dadosGeo$data)
# Podemos concluir que os valores previstos sao iguais aos valores da base de 
# dados por isso o erro vai ser zero pq a funçao kring é interprolador

#escolher um ponto especifico no grafico

xy = locator(1)#ir escolher um ponto no dado com o cursor

krig.dados <- krige.conv(dadosGeo, loc=xy, krige=krige.control(type.krige="ok", obj=exp.vg))

krig.dados$pred


# EXERCÍCIO: Como interpretar os valores em krig.dados$pred e krig.dados$krige.var 


##########
# PASSO II- prever sobre uma grelha
#           OBJETIVO: Construir um mapa com os valores preditos na grelha
#
# Para criar uma grelha de 40 por 40 sobreposta ao domínio original, escreva:
g <-list(xg=seq(min(dadosGeo$coords[,1]), max(dadosGeo$coords[,1]), length=40),#cria sequencia desde o minimo ate ao maximo de 40 em 40
         yg=seq(min(dadosGeo$coords[,2]), max(dadosGeo$coords[,2]), length=40));g #vamos ter 40x40 pontos(1600)

# e defina as novas localizações como
novos.locs <- expand.grid(g) #combinar essas sequências atraves do expand.grid
class(novos.locs)
dim(novos.locs) # 2 pq é abcissa e ordenada
# para desenhar a grelha, basta digitar:
plot(novos.locs,pch=20,main="40 by 40 prediction grid",xlab="X coordinate",ylab="Y coordinate")

#Vamos prever nos 1600 pontos(40x40) à custa dos 150 observados
#the rest follows as before:
krig.dados <- krige.conv(dadosGeo,loc=novos.locs,krige=krige.control(type.krige="ok", obj=exp.vg))

#Ver em formato de mapa:
#to produce an image, contour or perspective plot of the predicted values, type:
contour(krig.dados, filled=TRUE, coords.data=dados$coords, main="Estimativas de Kriging")


#to produce an image, contour or perspective plot of the kriging variances, type:
contour(krig.dados, val=sqrt(krig.dados$krige.var),
        filled=TRUE, coords.data=dados$coords, main="Desvio Padrao de Kriging")


#Ficha 2 - Kriging Universal

#############
# 
require(geoR)
data(ca20)
help(ca20)
summary(ca20)
names(ca20)

points(ca20, borders=ca20$borders, xlab="X",ylab="Y",main="Dados de calcio observados", cex.main=1.0)
polygon(ca20$reg1) #north west
polygon(ca20$reg2) #north east
polygon(ca20$reg3) # south
text(x=5310.6, y=5567.2, "1", col="red")
text(x=5861.4, y=5649.6, "2", col="red")
text(x=5848.4, y=5064.1, "3", col="red")

## Como modelar a esperança/tendência do processo espacial? 
aux.lm=lm(ca20$data~area+ca20$coords[,2], data=ca20)
summary(aux.lm)

###########
# QUESTÃO 1 – Que conclui sobre a esperança/tendência deste processo espacial?
###########
# O processo espacial Y(x) não é estacionário na média. Um possivel modelo para
# E[Y(x)] = mu(x) = 163.69 + 5.96*Se(area=2) + 7.19*Se(area=3) -0.0228*Latitude(x)
# - A concentração média do cálcio da área 2 é cerca de 5.96 unidades superior ao valor 
#   médio da área 1, fixando os valores das restantes covariáveis
# - A concentração média do cálcio da área 3 é cerca de 7.19 unidades superior ao valor  
#   médio da área 1, fixando os valores das restantes covariáveis
# - Por cada aumento unitário da latitude, espera-se que a concentração do cálcio diminua 
#   cerca de 0.0228 unidades, fixando os valores das restantes covariáveis  



## Como modelar a dependência/correlação espacial? 
v <- variog(ca20, trend=~area+ca20$coords[,2], max.dist=700)
plot(v, main="Variograma dos residuos (apos excluir tendencia)", cex.main=1.0, ylim=range(0,120))
var.exp <- variofit(v, ini=c(100, 200), nug=40, cov.model="exponential")
var.exp
lines(var.exp, col="red",lty=2)


#Predição espacial – kriging universal (com tendencia que depende das localizaçoes)

## defenir grelha rectangular (definir os pontos interiores do gráfico) cordenadas
gr0x <- seq(4900,6000, by=50)
gr0y <- seq(4800,5800,by=50)
gr0 <- expand.grid(gr0x, gr0y)
dim(gr0) #pontos todos dentro da grelha
points(ca20)
points(gr0, pch=".",cex=2)
## selecionar pontos da grelha dentro da área estudada
gr <- polygrid(gr0x, gr0y, bor=ca20$borders)
dim(gr) #pontos so dentro do mapa que é o que queremos estimar (292), 2 pq temos 2 coordeadas x e y
points(gr, pch=".", col=2, cex=2)

## criar covariavel "area" nas novas localizações
gr.area <- numeric(nrow(gr))
gr.area[.geoR_inout(gr, poly=ca20$reg1, bound=T)] <- 1
gr.area[.geoR_inout(gr, poly=ca20$reg2, bound=T)] <- 2
gr.area[.geoR_inout(gr, poly=ca20$reg3, bound=T)] <- 3
gr.area <- as.factor(gr.area)

# kriging universal= "ok"+tren.d=...+tren.l=...
KC <- krige.control(type.krige = "ok", trend.d=~area+ca20$coords[,2], #trend.d - vetor com 178, cada latitude tem um valor de area (area 1, 2 ou 3)
                    trend.l=~gr.area+gr[,2], obj=var.exp) #trend.l - vetor com 292 (para area nova a estimar)
#gr[,2]-latitude dos novos pontos

kr <- krige.conv(geodata=ca20, locations=gr0, krige=KC, borders=ca20$borders)

# Mapas mais usuais a 2D 
contour(kr, filled=TRUE, main="Estimativas de Kriging")
contour(kr, val=sqrt(kr$krige.var),
        filled=TRUE, coords.data=ca20$coords, main="Desvio Padrao de Kriging")




#############################################
### PARTE FINAL - usar altitude como preditor

# QUESTÃO 3 – Repita todo o processo de modelação dos dados do cálcio, mas agora 
# também considerando a covariável “altitude”. Para que tal seja possível terá que 
# previamente fazer predição desta covariável nas novas localizações. 
# Quais as principais conclusões?

#########
# PASSO I - Precisamos estimar correlação espacial presente nos residuos do cálcio
#           depois de removermos efeito da área, latitude e altitude.
names(ca20)
aux <- lm(ca20$data~altitude+area+ca20$coords, data=ca20)
summary(aux) 
#criamos novo modelo com a altitude e vimos que a variavel coordseast (longitude) continua a nao ser significativa (alfa=0.1)
aux <- lm(ca20$data~altitude+area+ca20$coords[,2], data=ca20) #retiramos a variavel nao significativa
summary(aux)


#variograma empirico retirando tb o efeito da altitude
v <- variog(ca20, trend=~altitude+area+ca20$coords[,2], max.dist=700)
plot(v, main="Variograma dos residuos (apos excluir tendencia)", cex.main=1.0, ylim=range(0,120))
var.exp1 <- variofit(v, ini=c(100, 200), nug=40, cov.model="exponential")
var.exp1
#var.exp = variograma teórico obtido retirando efeito da area e latitude (da questao anterior)
lines(var.exp, col="red",lty=2) 
#var.exp1 = variograma teórico obtido retirando efeito da area, latitude e ALTITUDE
lines(var.exp1, col="blue",lty=2)

##########
# PASSO II - Precisamos estimar (recorrendo ao kriging) a altitude em todos os pontos da grelha de predição
#            (292 pontos), à custa dos 178 altitudes observadas.
length(ca20$coords[,2]); length(gr[,2]); dim(gr)

# Considere-se agora o processo espacial Y(x)=altitude na localização x
dados_alt <- as.geodata(cbind(ca20$coords, ca20$covariate$altitude)) #tamos a criar uma nova "base de dados" com as cordenaas e a altura
plot(dados_alt)
points(dados_alt)

# Qual a estrutura de correlação espacial presente nos dados da altitude (depois de removermos efeito das coordenadas)?
v_alt <- variog(dados_alt, trend=~ca20$coords, max.dist=700) #trend=~ca20$coords = trend="1st" 

plot(v_alt, main="Variograma dos residuos ALTITUDE (apos excluir tendencia)", cex.main=1.0)
var_alt.exp <- variofit(v_alt, ini=c(0.15, 400), nug=0.03, cov.model="exponential")
var_alt.exp
lines(var_alt.exp, lty=2)

KC_alt <- krige.control(type.krige = "ok", trend.d=~dados_alt$coords[,1]+dados_alt$coords[,2], 
                        trend.l=~gr[,1]+gr[,2], obj=var_alt.exp)

kr_alt <- krige.conv(geodata=dados_alt, locations=gr0, krige=KC_alt, borders=ca20$borders)

contour(kr_alt, filled=TRUE, main="Estimativas de Kriging - ALTITUDE")
length(kr_alt$predict)


###########
# PASSO III - Estimar superficie de cálcio, assumindo altitude, area e latitude como covariáveis
# 
KC1 <- krige.control(type.krige = "ok", trend.d=~altitude+area+ca20$coords[,2], 
                     trend.l=~kr_alt$predict+gr.area+gr[,2], obj=var.exp1)
kr1 <- krige.conv(geodata=ca20, locations=gr0, krige=KC1, borders=ca20$borders)

# Mapas mais usuais a 2D 
contour(kr, filled=TRUE, main="Estimativas de Kriging (3 preditores)")
contour(kr, val=sqrt(kr$krige.var),
        filled=TRUE, coords.data=ca20$coords, main="Desvio Padrao de Kriging")

summary(kr$predict)
summary(kr1$predict)




## 16/11
# Ficha 3

library(spmodel)
library(ggplot2)

View(sulfato)
sulfate$sulfate
View(sulfate$preds)

ggplot(sulfate, aes(color = sulfate)) +
  geom_sf(size = 2) +
  scale_color_viridis_c(limits = c(0, 45)) +
  theme_gray(base_size = 14)# nao é estacionario na media

# ajustar modelo linear com um intercepto E[y(x)]=miu
spmod <- splm(sulfate ~ 1, data = sulfate, spcov_type = "exponential")
summary(spmod)

tidy(spmod)
glance(spmod)
predict(spmod, newdata = sulfate_preds)
aug_preds <- augment(spmod, newdata = sulfate_preds)
print(aug_preds)
ggplot(aug_preds, aes(color = .fitted)) +
  geom_sf(size = 2) +
  scale_color_viridis_c(limits = c(0, 45)) +
  theme_gray(base_size = 14)

